config.php
register.php
login.php